import React from 'react';
import { Layout } from '../components/Layout';
import { Button, SectionTitle, Card, Badge, Breadcrumb } from '../components/UI';
import { Search, Filter, Calendar, MapPin, Clock, CheckCircle, SlidersHorizontal, ChevronRight, Star } from 'lucide-react';

// --- COURSES INFO (LIST) ---
export const CoursesInfo: React.FC = () => {
  return (
    <Layout>
      <div className="container mx-auto px-4 lg:px-8 py-12">
        <Breadcrumb items={[{ label: 'Cursos', path: '#' }, { label: 'Informações' }]} />
        <div className="flex flex-col md:flex-row justify-between items-end mb-8 gap-4">
          <SectionTitle title="Catálogo de Cursos" subtitle="Explore todos os cursos disponíveis." />
          <div className="flex gap-2 w-full md:w-auto">
            <div className="relative flex-grow md:w-64">
              <input type="text" placeholder="Buscar curso..." className="w-full bg-sae-card border border-sae-border rounded-lg pl-10 pr-4 py-2.5 text-white focus:border-sae-accent outline-none"/>
              <Search size={18} className="absolute left-3 top-3 text-sae-muted"/>
            </div>
            <Button variant="secondary" className="px-3"><Filter size={18}/></Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {[1, 2, 3, 4, 5, 6, 7, 8].map(i => (
            <Card key={i} hoverEffect>
              <div className="aspect-video bg-gray-800 relative">
                 <img src={`https://picsum.photos/seed/c${i}/400/225`} alt="Course" className="w-full h-full object-cover"/>
                 <div className="absolute top-2 right-2"><Badge variant="primary">Online</Badge></div>
              </div>
              <div className="p-5">
                <div className="text-xs text-sae-accent mb-1 font-semibold uppercase">Vendas</div>
                <h3 className="font-bold text-white text-lg leading-tight mb-2">Técnicas de Persuasão {i}</h3>
                <p className="text-sae-muted text-sm mb-4 line-clamp-2">Aprenda a influenciar decisões e fechar mais negócios.</p>
                <div className="flex items-center justify-between text-xs text-sae-muted pt-4 border-t border-sae-border/50">
                  <span>Prof. Silva</span>
                  <span>12h • Certificado</span>
                </div>
              </div>
            </Card>
          ))}
        </div>
        
        {/* Pagination */}
        <div className="flex justify-center mt-12 gap-2">
          <Button variant="outline" size="sm" disabled>Anterior</Button>
          <Button variant="primary" size="sm">1</Button>
          <Button variant="secondary" size="sm">2</Button>
          <Button variant="secondary" size="sm">3</Button>
          <Button variant="outline" size="sm">Próximo</Button>
        </div>
      </div>
    </Layout>
  );
};

// --- COURSES PRESENCIAL ---
export const CoursesPresencial: React.FC = () => {
  return (
    <Layout>
      <div className="container mx-auto px-4 lg:px-8 py-12">
        <Breadcrumb items={[{ label: 'Cursos', path: '#' }, { label: 'Presenciais' }]} />
        <SectionTitle title="Treinamentos Presenciais" />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
           {/* Filters */}
           <div className="lg:col-span-1 space-y-6">
             <Card className="p-6 sticky top-24">
               <h3 className="font-bold text-white mb-4 flex items-center gap-2"><MapPin size={18}/> Filtrar por Local</h3>
               <select className="w-full bg-sae-darker border border-sae-border rounded-lg p-2.5 text-sae-text mb-4">
                 <option>Todas as unidades</option>
                 <option>São Paulo - Matriz</option>
                 <option>Rio de Janeiro</option>
                 <option>Belo Horizonte</option>
               </select>
               <h3 className="font-bold text-white mb-4 flex items-center gap-2 mt-6"><Calendar size={18}/> Data</h3>
               <input type="date" className="w-full bg-sae-darker border border-sae-border rounded-lg p-2.5 text-sae-text" />
             </Card>
           </div>

           {/* List */}
           <div className="lg:col-span-2 space-y-6">
             {[1, 2, 3].map(i => (
               <div key={i} className="flex flex-col md:flex-row bg-sae-card border border-sae-border rounded-xl overflow-hidden group">
                 <div className="md:w-48 bg-gray-800 relative">
                    <img src={`https://picsum.photos/seed/p${i}/300/300`} className="w-full h-full object-cover"/>
                 </div>
                 <div className="p-6 flex-1">
                   <div className="flex justify-between items-start mb-2">
                     <Badge variant="secondary">Presencial</Badge>
                     <span className="text-sae-accent font-bold">15 Vagas</span>
                   </div>
                   <h3 className="text-xl font-bold text-white mb-2">Imersão em Liderança {i}</h3>
                   <div className="grid grid-cols-2 gap-y-2 text-sm text-sae-muted mb-4">
                      <div className="flex items-center gap-2"><Calendar size={14}/> 20 Out 2024</div>
                      <div className="flex items-center gap-2"><Clock size={14}/> 09:00 - 18:00</div>
                      <div className="flex items-center gap-2 col-span-2"><MapPin size={14}/> Auditório Principal - SP</div>
                   </div>
                   <div className="flex gap-3">
                     <Button size="sm">Inscrever-se</Button>
                     <Button size="sm" variant="outline">Mais Info</Button>
                   </div>
                 </div>
               </div>
             ))}
           </div>
        </div>
      </div>
    </Layout>
  );
};

// --- COMBOS ---
export const Combos: React.FC = () => {
  return (
    <Layout>
      <div className="container mx-auto px-4 lg:px-8 py-12">
        <Breadcrumb items={[{ label: 'Cursos', path: '#' }, { label: 'Combos & Ofertas' }]} />
        <SectionTitle title="Pacotes Promocionais" subtitle="Economize adquirindo trilhas completas de conhecimento." />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {[1, 2, 3, 4].map(i => (
            <div key={i} className="bg-sae-card border border-sae-border rounded-2xl p-8 relative overflow-hidden hover:border-sae-accentAlt transition-colors">
              <div className="absolute top-0 right-0 bg-sae-accentAlt text-sae-darker font-bold px-4 py-1 rounded-bl-xl text-sm">
                -30% OFF
              </div>
              <h3 className="text-2xl font-bold text-white mb-2">Combo Mestre de Vendas</h3>
              <p className="text-sae-muted mb-6">Domine do básico ao avançado em uma única trilha.</p>
              
              <div className="space-y-3 mb-8">
                {['Negociação Básica', 'Psicologia do Consumidor', 'Fechamento Avançado'].map(c => (
                  <div key={c} className="flex items-center gap-2 text-sm text-sae-text">
                    <CheckCircle size={16} className="text-sae-accentAlt"/> {c}
                  </div>
                ))}
              </div>

              <div className="flex items-end justify-between border-t border-sae-border pt-6">
                <div>
                  <div className="text-sm text-sae-muted line-through">R$ 1.200,00</div>
                  <div className="text-3xl font-bold text-white">R$ 840,00</div>
                </div>
                <Button className="bg-sae-accentAlt text-sae-darker hover:bg-green-400">Comprar Agora</Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </Layout>
  );
};

// --- FILTER PAGE ---
export const CourseFilter: React.FC = () => {
  return (
    <Layout>
      <div className="flex h-[calc(100vh-80px)]">
        {/* Sidebar Fixed */}
        <aside className="w-80 bg-sae-card border-r border-sae-border overflow-y-auto hidden lg:block p-6">
          <div className="flex items-center gap-2 font-bold text-white text-lg mb-6">
            <SlidersHorizontal size={20} className="text-sae-accent"/> Filtros Avançados
          </div>
          
          <div className="space-y-8">
            <div>
              <h4 className="text-sm font-bold text-sae-text uppercase tracking-wider mb-3">Nível</h4>
              <div className="space-y-2">
                {['Iniciante', 'Intermediário', 'Avançado'].map(l => (
                  <label key={l} className="flex items-center gap-2 text-sae-muted hover:text-white cursor-pointer">
                    <input type="checkbox" className="rounded border-sae-border bg-sae-darker text-sae-accent" />
                    {l}
                  </label>
                ))}
              </div>
            </div>
            
            <div>
              <h4 className="text-sm font-bold text-sae-text uppercase tracking-wider mb-3">Preço</h4>
              <input type="range" className="w-full h-2 bg-sae-darker rounded-lg appearance-none cursor-pointer accent-sae-accent"/>
              <div className="flex justify-between text-xs text-sae-muted mt-2">
                <span>R$ 0</span>
                <span>R$ 500+</span>
              </div>
            </div>

            <div>
              <h4 className="text-sm font-bold text-sae-text uppercase tracking-wider mb-3">Avaliação</h4>
              {[5, 4, 3].map(stars => (
                <label key={stars} className="flex items-center gap-2 text-sae-muted mb-2 cursor-pointer">
                  <input type="radio" name="stars" className="bg-sae-darker border-sae-border text-sae-accent"/>
                  <div className="flex text-yellow-500">
                    {[...Array(5)].map((_, i) => <Star key={i} size={12} fill={i < stars ? "currentColor" : "none"}/>)}
                  </div>
                  <span className="text-xs">& acima</span>
                </label>
              ))}
            </div>

            <div className="pt-4 flex gap-2">
              <Button className="w-full" size="sm">Aplicar</Button>
              <Button variant="outline" className="w-full" size="sm">Limpar</Button>
            </div>
          </div>
        </aside>

        {/* Results Area */}
        <div className="flex-1 overflow-y-auto bg-sae-dark p-6 lg:p-12">
           <div className="flex justify-between items-center mb-6">
             <div className="text-sae-muted">Mostrando <strong>24</strong> resultados</div>
             <div className="flex items-center gap-2">
               <span className="text-sm text-sae-muted">Ordenar por:</span>
               <select className="bg-sae-card border border-sae-border rounded px-3 py-1 text-sm text-white">
                 <option>Mais Relevantes</option>
                 <option>Menor Preço</option>
                 <option>Novidades</option>
               </select>
             </div>
           </div>

           <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
             {[1, 2, 3, 4, 5, 6].map(i => (
               <Card key={i} className="flex flex-col">
                 <div className="h-40 bg-gray-800 relative">
                   <img src={`https://picsum.photos/seed/f${i}/400/200`} className="w-full h-full object-cover"/>
                 </div>
                 <div className="p-4 flex-1">
                   <h3 className="font-bold text-white mb-2">Curso Avançado de Filtros</h3>
                   <div className="text-sm text-sae-muted mb-4">Aprenda a refinar suas buscas como um profissional.</div>
                   <div className="flex justify-between items-center mt-auto">
                     <span className="font-bold text-sae-accent">R$ 199,90</span>
                     <Button size="sm" variant="ghost" className="p-0 text-sae-accent hover:bg-transparent">Ver <ChevronRight size={16}/></Button>
                   </div>
                 </div>
               </Card>
             ))}
           </div>
        </div>
      </div>
    </Layout>
  );
};