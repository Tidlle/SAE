import React from 'react';
import { Layout } from '../components/Layout';
import { Button, SectionTitle, Card, Badge, Breadcrumb } from '../components/UI';
import { Mail, Phone, MapPin, Clock, Linkedin, Twitter, Calendar, Pin } from 'lucide-react';

// --- TEAM PAGE ---
export const Team: React.FC = () => {
  return (
    <Layout>
      <div className="container mx-auto px-4 lg:px-8 py-12">
        <Breadcrumb items={[{ label: 'Equipe' }]} />
        <SectionTitle title="Nossa Equipe" subtitle="Conheça os especialistas por trás do SAE." />
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
            <Card key={i} className="text-center p-6 group">
              <div className="w-24 h-24 mx-auto rounded-full overflow-hidden mb-4 border-2 border-sae-accent/30 group-hover:border-sae-accent transition-colors">
                <img src={`https://picsum.photos/seed/user${i}/200`} alt="Team Member" className="w-full h-full object-cover" />
              </div>
              <h3 className="text-lg font-bold text-white">Nome do Membro</h3>
              <p className="text-sae-accent text-sm mb-3">Instrutor Sênior</p>
              <p className="text-sae-muted text-xs mb-4">Especialista em vendas B2B com mais de 10 anos de experiência.</p>
              <div className="flex justify-center gap-3">
                <button className="text-sae-muted hover:text-white"><Linkedin size={16}/></button>
                <button className="text-sae-muted hover:text-white"><Twitter size={16}/></button>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </Layout>
  );
};

// --- ABOUT PAGE ---
export const About: React.FC = () => {
  return (
    <Layout>
      <div className="bg-sae-darker border-b border-sae-border py-16">
        <div className="container mx-auto px-4 lg:px-8 text-center">
          <Badge variant="primary">Institucional</Badge>
          <h1 className="text-4xl font-bold text-white mt-4 mb-6">Sobre o SAE</h1>
          <p className="text-lg text-sae-muted max-w-2xl mx-auto">
            Nossa missão é capacitar profissionais através de uma metodologia inovadora e prática.
          </p>
        </div>
      </div>
      
      <div className="container mx-auto px-4 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
          {['Missão', 'Visão', 'Valores'].map((item) => (
            <Card key={item} className="p-8 text-center border-t-4 border-t-sae-accent">
              <h3 className="text-2xl font-bold text-white mb-4">{item}</h3>
              <p className="text-sae-muted">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore.
              </p>
            </Card>
          ))}
        </div>

        <SectionTitle title="Perguntas Frequentes" align="center" />
        <div className="max-w-2xl mx-auto mt-8 space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="border border-sae-border rounded-lg bg-sae-card overflow-hidden">
              <button className="w-full px-6 py-4 text-left font-medium text-white flex justify-between items-center">
                Como acesso meu certificado?
                <span className="text-sae-accent">+</span>
              </button>
            </div>
          ))}
        </div>
      </div>
    </Layout>
  );
};

// --- CONTACTS PAGE ---
export const Contacts: React.FC = () => {
  return (
    <Layout>
      <div className="container mx-auto px-4 lg:px-8 py-12">
        <Breadcrumb items={[{ label: 'Contatos' }]} />
        <SectionTitle title="Fale Conosco" />

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Form */}
          <Card className="p-8">
            <form className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-sae-muted mb-2">Nome</label>
                  <input type="text" className="w-full bg-sae-darker border border-sae-border rounded-lg px-4 py-3 text-white focus:outline-none focus:border-sae-accent" placeholder="Seu nome" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-sae-muted mb-2">Email</label>
                  <input type="email" className="w-full bg-sae-darker border border-sae-border rounded-lg px-4 py-3 text-white focus:outline-none focus:border-sae-accent" placeholder="seu@email.com" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-sae-muted mb-2">Assunto</label>
                <select className="w-full bg-sae-darker border border-sae-border rounded-lg px-4 py-3 text-white focus:outline-none focus:border-sae-accent">
                  <option>Dúvida sobre cursos</option>
                  <option>Suporte técnico</option>
                  <option>Parcerias</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-sae-muted mb-2">Mensagem</label>
                <textarea rows={5} className="w-full bg-sae-darker border border-sae-border rounded-lg px-4 py-3 text-white focus:outline-none focus:border-sae-accent" placeholder="Como podemos ajudar?"></textarea>
              </div>
              <Button type="button" className="w-full">Enviar Mensagem</Button>
            </form>
          </Card>

          {/* Info */}
          <div className="space-y-8">
            <div className="grid gap-6">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-sae-card border border-sae-border rounded-lg text-sae-accent"><MapPin size={24}/></div>
                <div>
                  <h4 className="font-bold text-white text-lg">Nosso Escritório</h4>
                  <p className="text-sae-muted">Av. Paulista, 1000, Bela Vista<br/>São Paulo - SP, 01310-100</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="p-3 bg-sae-card border border-sae-border rounded-lg text-sae-accent"><Mail size={24}/></div>
                <div>
                  <h4 className="font-bold text-white text-lg">Email</h4>
                  <p className="text-sae-muted">contato@sae-educacional.com</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="p-3 bg-sae-card border border-sae-border rounded-lg text-sae-accent"><Phone size={24}/></div>
                <div>
                  <h4 className="font-bold text-white text-lg">Telefone</h4>
                  <p className="text-sae-muted">(11) 3000-0000</p>
                  <p className="text-sae-muted text-sm mt-1">Seg-Sex, 9h às 18h</p>
                </div>
              </div>
            </div>
            
            {/* Map Placeholder */}
            <div className="h-64 bg-sae-card border border-sae-border rounded-xl flex items-center justify-center text-sae-muted">
              <span className="flex items-center gap-2"><MapPin/> Mapa do Google</span>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

// --- NOTICES PAGE ---
export const Notices: React.FC = () => {
  return (
    <Layout>
      <div className="container mx-auto px-4 lg:px-8 py-12">
        <Breadcrumb items={[{ label: 'Avisos' }]} />
        <SectionTitle title="Mural de Avisos" subtitle="Fique por dentro das últimas novidades." />

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Filters Sidebar */}
          <div className="lg:w-1/4 space-y-6">
            <Card className="p-6">
              <h3 className="font-bold text-white mb-4">Categorias</h3>
              <div className="space-y-2">
                {['Geral', 'Manutenção', 'Eventos', 'Urgente'].map(cat => (
                  <label key={cat} className="flex items-center gap-2 text-sae-muted hover:text-white cursor-pointer">
                    <input type="checkbox" className="rounded border-sae-border bg-sae-darker text-sae-accent focus:ring-0" />
                    {cat}
                  </label>
                ))}
              </div>
            </Card>
          </div>

          {/* Feed */}
          <div className="lg:w-3/4 space-y-6">
            {/* Pinned */}
            <Card className="p-6 border-sae-accent/40 bg-sae-accent/5">
              <div className="flex items-start gap-4">
                <div className="p-2 bg-sae-accent text-sae-darker rounded shrink-0">
                  <Pin size={20} />
                </div>
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <Badge variant="warning">Urgente</Badge>
                    <span className="text-xs text-sae-muted flex items-center gap-1"><Calendar size={12}/> 12 Out 2024</span>
                  </div>
                  <h3 className="text-xl font-bold text-white mb-2">Manutenção Programada do Sistema</h3>
                  <p className="text-sae-muted mb-4">O sistema passará por uma atualização neste fim de semana. Alguns serviços podem ficar indisponíveis.</p>
                  <Button size="sm" variant="outline">Ler Comunicado</Button>
                </div>
              </div>
            </Card>

            {/* Normal List */}
            {[1, 2, 3, 4].map(i => (
              <Card key={i} className="p-6">
                <div className="flex items-center gap-3 mb-2">
                  <Badge variant="secondary">Geral</Badge>
                  <span className="text-xs text-sae-muted">10 Out 2024</span>
                </div>
                <h3 className="text-lg font-bold text-white mb-2">Nova grade de cursos disponível</h3>
                <p className="text-sae-muted text-sm mb-4">Confira os novos treinamentos adicionados ao catálogo para o próximo trimestre.</p>
                <a href="#" className="text-sae-accent text-sm font-medium hover:underline">Ler mais</a>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </Layout>
  );
};