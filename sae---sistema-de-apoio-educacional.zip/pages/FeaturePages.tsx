import React, { useState } from 'react';
import { Layout } from '../components/Layout';
import { Button, SectionTitle, Card, Badge, Breadcrumb } from '../components/UI';
import { Play, Clock, Search, Award, TrendingUp, BookOpen, CheckCircle, Download } from 'lucide-react';

// --- VIDEOS PAGE ---
export const Videos: React.FC = () => {
  const categories = ['Todos', 'Iniciante', 'Vendas', 'Sistema', 'Liderança'];
  const [activeCat, setActiveCat] = useState('Todos');

  return (
    <Layout>
      <div className="container mx-auto px-4 lg:px-8 py-12">
        <Breadcrumb items={[{ label: 'Vídeos' }]} />
        <SectionTitle title="Tutoriais em Vídeo" subtitle="Aprenda rápido com nossos conteúdos curtos e diretos." />

        {/* Filters */}
        <div className="flex flex-col md:flex-row justify-between items-center mb-8 gap-4">
          <div className="flex gap-2 overflow-x-auto pb-2 w-full md:w-auto">
            {categories.map(cat => (
              <button 
                key={cat}
                onClick={() => setActiveCat(cat)}
                className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${activeCat === cat ? 'bg-sae-accent text-sae-darker' : 'bg-sae-card border border-sae-border text-sae-text hover:border-sae-accent'}`}
              >
                {cat}
              </button>
            ))}
          </div>
          <div className="relative w-full md:w-64">
            <input type="text" placeholder="Buscar vídeo..." className="w-full bg-sae-darker border border-sae-border rounded-lg pl-9 pr-4 py-2 text-sm text-white focus:border-sae-accent outline-none"/>
            <Search size={14} className="absolute left-3 top-3 text-sae-muted"/>
          </div>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map(i => (
            <div key={i} className="group cursor-pointer">
              <div className="relative aspect-video rounded-xl overflow-hidden bg-sae-card mb-3">
                <img src={`https://picsum.photos/seed/vid${i}/500/300`} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity"/>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-12 h-12 bg-sae-accent/90 rounded-full flex items-center justify-center text-sae-darker transform group-hover:scale-110 transition-transform">
                    <Play size={20} fill="currentColor"/>
                  </div>
                </div>
                <div className="absolute bottom-2 right-2 bg-black/70 text-white text-xs px-2 py-0.5 rounded">04:20</div>
              </div>
              <h3 className="font-bold text-white group-hover:text-sae-accent transition-colors">Como cadastrar novos clientes no sistema</h3>
              <div className="flex items-center gap-2 text-xs text-sae-muted mt-1">
                <span>Tutoriais</span>
                <span>•</span>
                <span>2 dias atrás</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </Layout>
  );
};

// --- QUIZ PAGE (What to study) ---
export const Quiz: React.FC = () => {
  const [step, setStep] = useState(1);
  const [showResult, setShowResult] = useState(false);

  const handleNext = () => {
    if (step < 3) setStep(step + 1);
    else setShowResult(true);
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 lg:px-8 py-12">
        <Breadcrumb items={[{ label: 'Cursos', path: '#' }, { label: 'O que estudar?' }]} />
        
        <div className="max-w-2xl mx-auto">
          {!showResult ? (
            <Card className="p-8">
              <div className="mb-8">
                <div className="flex justify-between text-sm text-sae-muted mb-2">
                  <span>Passo {step} de 3</span>
                  <span>{Math.round((step/3)*100)}%</span>
                </div>
                <div className="h-2 bg-sae-darker rounded-full overflow-hidden">
                  <div className="h-full bg-sae-accent transition-all duration-300" style={{ width: `${(step/3)*100}%` }}></div>
                </div>
              </div>

              <h2 className="text-2xl font-bold text-white mb-6">
                {step === 1 && "Qual seu principal objetivo profissional agora?"}
                {step === 2 && "Quanto tempo você tem disponível por semana?"}
                {step === 3 && "Qual área você sente mais dificuldade?"}
              </h2>

              <div className="space-y-4 mb-8">
                {[1, 2, 3].map((opt) => (
                  <label key={opt} className="flex items-center p-4 border border-sae-border rounded-lg cursor-pointer hover:bg-sae-border/30 transition-colors">
                    <input type="radio" name="q" className="w-4 h-4 text-sae-accent bg-sae-darker border-sae-border focus:ring-sae-accent" />
                    <span className="ml-3 text-sae-text">Opção de resposta {opt} para a pergunta atual.</span>
                  </label>
                ))}
              </div>

              <div className="flex justify-between">
                <Button variant="ghost" onClick={() => setStep(s => Math.max(1, s-1))} disabled={step === 1}>Voltar</Button>
                <Button onClick={handleNext}>{step === 3 ? 'Ver Recomendação' : 'Próximo'}</Button>
              </div>
            </Card>
          ) : (
            <div className="space-y-8 animate-fade-in">
              <Card className="p-8 text-center bg-gradient-to-b from-sae-card to-sae-darker">
                <div className="w-16 h-16 bg-sae-accent/20 rounded-full flex items-center justify-center text-sae-accent mx-auto mb-4">
                  <Award size={32} />
                </div>
                <h2 className="text-3xl font-bold text-white mb-2">Perfil: Negociador Estratégico</h2>
                <p className="text-sae-muted mb-6">Com base nas suas respostas, recomendamos focar em soft skills e fechamento.</p>
                <Button onClick={() => {setShowResult(false); setStep(1);}} variant="outline">Refazer Quiz</Button>
              </Card>

              <div>
                <h3 className="text-xl font-bold text-white mb-4">Cursos Recomendados para Você</h3>
                <div className="grid gap-4">
                  {[1, 2, 3].map(i => (
                    <div key={i} className="flex items-center gap-4 bg-sae-card p-4 rounded-lg border border-sae-border">
                       <div className="w-16 h-16 bg-gray-700 rounded-md shrink-0"></div>
                       <div className="flex-1">
                         <h4 className="font-bold text-white">Psicologia de Vendas Avançada</h4>
                         <p className="text-xs text-sae-muted">Online • 8 horas</p>
                       </div>
                       <Button size="sm">Acessar</Button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
};

// --- EVOLUTION PAGE ---
export const Evolution: React.FC = () => {
  return (
    <Layout>
      <div className="container mx-auto px-4 lg:px-8 py-12">
        <Breadcrumb items={[{ label: 'Minha Evolução' }]} />

        {/* Header Profile */}
        <div className="flex flex-col md:flex-row items-center gap-6 mb-12 bg-sae-card border border-sae-border p-8 rounded-2xl">
          <div className="w-24 h-24 rounded-full border-4 border-sae-accent p-1">
             <div className="w-full h-full bg-sae-darker rounded-full flex items-center justify-center text-2xl font-bold text-sae-muted">VE</div>
          </div>
          <div className="flex-1 text-center md:text-left">
            <h1 className="text-2xl font-bold text-white mb-1">Vendedor Exemplo</h1>
            <p className="text-sae-muted mb-4">Membro desde Jan 2024 • Nível Prata</p>
            <div className="w-full max-w-md bg-sae-darker h-2 rounded-full overflow-hidden mx-auto md:mx-0">
               <div className="bg-sae-accentAlt h-full w-[70%]"></div>
            </div>
            <div className="text-xs text-sae-muted mt-1">70% para o Nível Ouro</div>
          </div>
          <div className="flex gap-4">
            <div className="text-center px-4 border-r border-sae-border">
              <div className="text-2xl font-bold text-white">12</div>
              <div className="text-xs text-sae-muted">Cursos</div>
            </div>
            <div className="text-center px-4">
              <div className="text-2xl font-bold text-white">45h</div>
              <div className="text-xs text-sae-muted">Horas</div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* In Progress */}
          <Card className="p-6">
            <h3 className="font-bold text-white mb-6 flex items-center gap-2"><TrendingUp className="text-sae-accent"/> Em Progresso</h3>
            <div className="space-y-6">
              {[1, 2].map(i => (
                <div key={i}>
                  <div className="flex justify-between mb-2">
                    <span className="font-medium text-white">Gestão de Tempo para Vendas</span>
                    <span className="text-sae-accent">45%</span>
                  </div>
                  <div className="h-2 bg-sae-darker rounded-full overflow-hidden">
                    <div className="h-full bg-sae-accent w-[45%]"></div>
                  </div>
                  <div className="mt-2 flex justify-end">
                    <button className="text-xs text-sae-muted hover:text-white uppercase font-bold tracking-wide">Continuar</button>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Completed */}
          <Card className="p-6">
             <h3 className="font-bold text-white mb-6 flex items-center gap-2"><Award className="text-sae-accentAlt"/> Conquistas Recentes</h3>
             <div className="space-y-4">
               {[1, 2, 3].map(i => (
                 <div key={i} className="flex items-center gap-3 p-3 bg-sae-darker rounded-lg border border-sae-border">
                   <div className="p-2 bg-sae-accentAlt/20 text-sae-accentAlt rounded">
                     <CheckCircle size={16} />
                   </div>
                   <div className="flex-1">
                     <div className="font-medium text-white text-sm">Certificação Básica SAE</div>
                     <div className="text-xs text-sae-muted">Concluído em 10 Out</div>
                   </div>
                   <button className="text-sae-muted hover:text-sae-accent"><Download size={16}/></button>
                 </div>
               ))}
             </div>
             <Button variant="outline" className="w-full mt-6">Ver Todos os Certificados</Button>
          </Card>
        </div>
      </div>
    </Layout>
  );
};