import React from 'react';
import { Layout } from '../components/Layout';
import { Button, SectionTitle, Card, Badge } from '../components/UI';
import { ArrowRight, BookOpen, Users, Trophy, PlayCircle, Calendar, MapPin } from 'lucide-react';
import { Link } from 'react-router-dom';

export const Home: React.FC = () => {
  return (
    <Layout>
      {/* --- HERO SECTION --- */}
      <section className="relative py-20 lg:py-32 overflow-hidden">
        {/* Background Overlay */}
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?q=80&w=2070&auto=format&fit=crop')] bg-cover bg-center">
          <div className="absolute inset-0 bg-sae-dark/90 backdrop-blur-[2px]"></div>
        </div>

        <div className="container mx-auto px-4 lg:px-8 relative z-10">
          <div className="max-w-3xl">
            <Badge variant="primary">Novo Calendário 2024</Badge>
            <h1 className="text-4xl lg:text-6xl font-bold text-white mt-6 mb-6 leading-tight">
              Domine as Habilidades do <span className="text-transparent bg-clip-text bg-gradient-to-r from-sae-accent to-sae-accentAlt">Futuro</span>
            </h1>
            <p className="text-lg text-sae-muted mb-10 leading-relaxed max-w-xl">
              Acesse cursos exclusivos, materiais de apoio e acompanhe sua evolução profissional em uma plataforma feita para vendedores de alta performance.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link to="/cursos/info">
                <Button size="lg" className="w-full sm:w-auto">Explorar Cursos</Button>
              </Link>
              <Link to="/sobre">
                <Button variant="outline" size="lg" className="w-full sm:w-auto">Conheça o SAE</Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* --- STATS SECTION --- */}
      <section className="bg-sae-darker border-y border-sae-border py-12">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { icon: BookOpen, val: '150+', label: 'Cursos Disponíveis' },
              { icon: Users, val: '12k', label: 'Alunos Ativos' },
              { icon: Trophy, val: '95%', label: 'Taxa de Aprovação' },
              { icon: PlayCircle, val: '500h', label: 'Conteúdo em Vídeo' },
            ].map((stat, i) => (
              <div key={i} className="flex flex-col items-center text-center">
                <div className="mb-4 p-3 bg-sae-card rounded-full border border-sae-border text-sae-accent">
                  <stat.icon size={24} />
                </div>
                <div className="text-2xl font-bold text-white mb-1">{stat.val}</div>
                <div className="text-sm text-sae-muted">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* --- HIGHLIGHTS SECTION --- */}
      <section className="py-20">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="flex justify-between items-end mb-10">
            <SectionTitle title="Cursos em Destaque" subtitle="Os conteúdos mais acessados pela nossa equipe de vendas este mês." />
            <Link to="/cursos/info" className="hidden md:flex items-center gap-2 text-sae-accent font-medium hover:underline">
              Ver todos <ArrowRight size={16} />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[1, 2, 3].map((i) => (
              <Card key={i} hoverEffect className="group">
                <div className="h-48 overflow-hidden relative">
                  <img 
                    src={`https://picsum.photos/seed/course${i}/800/600`} 
                    alt="Course thumbnail" 
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute top-4 left-4">
                    <Badge variant="secondary">Vendas</Badge>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-white mb-2 group-hover:text-sae-accent transition-colors">Estratégias de Negociação Avançada</h3>
                  <div className="flex items-center gap-4 text-sm text-sae-muted mb-4">
                    <span className="flex items-center gap-1"><Users size={14}/> 450 alunos</span>
                    <span className="flex items-center gap-1"><Calendar size={14}/> 12h</span>
                  </div>
                  <Button variant="outline" className="w-full">Ver Detalhes</Button>
                </div>
              </Card>
            ))}
          </div>
          
          <div className="mt-8 text-center md:hidden">
            <Link to="/cursos/info">
              <Button variant="ghost">Ver todos os cursos <ArrowRight size={16} className="ml-2"/></Button>
            </Link>
          </div>
        </div>
      </section>

      {/* --- UPCOMING SECTION --- */}
      <section className="py-20 bg-sae-darker border-t border-sae-border">
        <div className="container mx-auto px-4 lg:px-8">
          <SectionTitle title="Próximos Cursos Presenciais" align="center" subtitle="Garanta sua vaga nos treinamentos presenciais da próxima semana." />
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-12">
             {[1, 2].map((i) => (
               <div key={i} className="flex flex-col sm:flex-row bg-sae-card border border-sae-border rounded-xl overflow-hidden hover:border-sae-accent/30 transition-colors">
                  <div className="sm:w-1/3 h-48 sm:h-auto relative">
                    <img src={`https://picsum.photos/seed/meet${i}/400/400`} alt="Event" className="w-full h-full object-cover"/>
                    <div className="absolute top-0 left-0 bg-sae-accent text-sae-darker font-bold px-3 py-1 rounded-br-lg text-sm">
                      15 OUT
                    </div>
                  </div>
                  <div className="p-6 flex flex-col justify-center sm:w-2/3">
                    <div className="flex items-center gap-2 text-sae-accentAlt text-xs font-bold uppercase tracking-wider mb-2">
                      <MapPin size={12}/> São Paulo - HQ
                    </div>
                    <h3 className="text-xl font-bold text-white mb-3">Workshop: Liderança 4.0</h3>
                    <p className="text-sae-muted text-sm mb-6 line-clamp-2">Um mergulho profundo nas novas tecnologias de gestão de pessoas.</p>
                    <Link to="/cursos/presenciais">
                      <Button size="sm" variant="secondary">Inscrever-se</Button>
                    </Link>
                  </div>
               </div>
             ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};