import React from 'react';
import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import { Home } from './pages/Home';
import { Team, About, Contacts, Notices } from './pages/Pages';
import { CoursesInfo, CoursesPresencial, Combos, CourseFilter } from './pages/CoursePages';
import { Videos, Quiz, Evolution } from './pages/FeaturePages';

const App: React.FC = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        
        {/* Institutional */}
        <Route path="/equipe" element={<Team />} />
        <Route path="/sobre" element={<About />} />
        <Route path="/contatos" element={<Contacts />} />
        <Route path="/avisos" element={<Notices />} />

        {/* Courses */}
        <Route path="/cursos/info" element={<CoursesInfo />} />
        <Route path="/cursos/presenciais" element={<CoursesPresencial />} />
        <Route path="/cursos/combos" element={<Combos />} />
        <Route path="/cursos/filtro" element={<CourseFilter />} />
        
        {/* Features */}
        <Route path="/videos" element={<Videos />} />
        <Route path="/quiz" element={<Quiz />} />
        <Route path="/evolucao" element={<Evolution />} />
      </Routes>
    </Router>
  );
};

export default App;