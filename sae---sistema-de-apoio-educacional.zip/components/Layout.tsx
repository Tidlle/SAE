import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Search, User, ChevronDown, Facebook, Twitter, Instagram, Youtube, MapPin, Mail, Phone } from 'lucide-react';
import { Button } from './UI';

const NAV_ITEMS = [
  { label: 'Início', path: '/' },
  { label: 'Equipe', path: '/equipe' },
  { label: 'Sobre SAE', path: '/sobre' },
  { label: 'Vídeos', path: '/videos' },
  { 
    label: 'Cursos', 
    path: '#',
    children: [
      { label: 'Informações', path: '/cursos/info' },
      { label: 'Presenciais', path: '/cursos/presenciais' },
      { label: 'Filtro Avançado', path: '/cursos/filtro' },
      { label: 'Combos', path: '/cursos/combos' },
      { label: 'O que estudar?', path: '/quiz' },
      { label: 'Evolução', path: '/evolucao' },
    ]
  },
  { label: 'Contatos', path: '/contatos' },
  { label: 'Avisos', path: '/avisos' },
];

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const location = useLocation();

  // Close mobile menu on route change
  useEffect(() => {
    setIsMobileMenuOpen(false);
    setActiveDropdown(null);
  }, [location.pathname]);

  const toggleDropdown = (label: string) => {
    if (activeDropdown === label) {
      setActiveDropdown(null);
    } else {
      setActiveDropdown(label);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-sae-dark text-sae-text">
      {/* --- NAVBAR --- */}
      <header className="sticky top-0 z-50 bg-sae-dark/95 backdrop-blur-md border-b border-sae-border shadow-lg">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="flex items-center justify-between h-20">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-2 group">
              <div className="w-10 h-10 bg-sae-accent rounded-lg flex items-center justify-center text-sae-darker font-bold text-xl group-hover:scale-105 transition-transform">
                S
              </div>
              <span className="font-bold text-2xl tracking-tight text-white">SAE<span className="text-sae-accent">.</span></span>
            </Link>

            {/* Desktop Menu */}
            <nav className="hidden lg:flex items-center gap-8">
              {NAV_ITEMS.map((item) => (
                <div key={item.label} className="relative group">
                  <Link 
                    to={item.path} 
                    className={`flex items-center gap-1 text-sm font-medium transition-colors hover:text-sae-accent ${location.pathname === item.path ? 'text-sae-accent' : 'text-sae-text'}`}
                  >
                    {item.label}
                    {item.children && <ChevronDown size={14} />}
                  </Link>
                  
                  {/* Dropdown */}
                  {item.children && (
                    <div className="absolute top-full left-0 w-56 pt-4 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 transform translate-y-2 group-hover:translate-y-0">
                      <div className="bg-sae-card border border-sae-border rounded-lg shadow-xl overflow-hidden py-2">
                        {item.children.map((child) => (
                          <Link 
                            key={child.path}
                            to={child.path}
                            className="block px-4 py-2 text-sm text-sae-muted hover:bg-sae-border/50 hover:text-sae-accent transition-colors"
                          >
                            {child.label}
                          </Link>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </nav>

            {/* Actions */}
            <div className="hidden lg:flex items-center gap-4">
              <button className="p-2 text-sae-muted hover:text-sae-accent transition-colors">
                <Search size={20} />
              </button>
              <Link to="/evolucao" className="flex items-center gap-2 pl-4 border-l border-sae-border">
                <div className="text-right hidden xl:block">
                  <div className="text-xs text-sae-muted">Bem-vindo,</div>
                  <div className="text-sm font-bold truncate max-w-[100px]">Vendedor</div>
                </div>
                <div className="w-10 h-10 bg-sae-card border border-sae-border rounded-full flex items-center justify-center text-sae-accent">
                  <User size={20} />
                </div>
              </Link>
            </div>

            {/* Mobile Toggle */}
            <div className="flex items-center gap-4 lg:hidden">
              <button className="p-2 text-sae-muted hover:text-sae-accent">
                <Search size={20} />
              </button>
              <button 
                onClick={() => setIsMobileMenuOpen(true)}
                className="p-2 text-sae-text hover:text-sae-accent"
              >
                <Menu size={28} />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* --- MOBILE DRAWER --- */}
      <div className={`fixed inset-0 z-[60] lg:hidden transition-opacity duration-300 ${isMobileMenuOpen ? 'opacity-100 visible' : 'opacity-0 invisible'}`}>
        <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setIsMobileMenuOpen(false)} />
        <div className={`absolute top-0 left-0 w-[85%] max-w-[320px] h-full bg-sae-darker border-r border-sae-border shadow-2xl transition-transform duration-300 transform ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}`}>
          <div className="flex flex-col h-full">
            <div className="p-6 flex items-center justify-between border-b border-sae-border">
               <span className="font-bold text-2xl tracking-tight text-white">SAE<span className="text-sae-accent">.</span></span>
               <button onClick={() => setIsMobileMenuOpen(false)} className="text-sae-muted hover:text-white">
                 <X size={24} />
               </button>
            </div>
            
            <div className="flex-1 overflow-y-auto py-6 px-4">
              <nav className="space-y-2">
                {NAV_ITEMS.map((item) => (
                  <div key={item.label}>
                    {item.children ? (
                      <div>
                        <button 
                          onClick={() => toggleDropdown(item.label)}
                          className="flex items-center justify-between w-full px-4 py-3 text-left font-medium text-sae-text hover:bg-sae-card rounded-lg transition-colors"
                        >
                          {item.label}
                          <ChevronDown size={16} className={`transition-transform duration-200 ${activeDropdown === item.label ? 'rotate-180' : ''}`} />
                        </button>
                        <div className={`overflow-hidden transition-all duration-300 ${activeDropdown === item.label ? 'max-h-96 opacity-100 mt-2' : 'max-h-0 opacity-0'}`}>
                          <div className="pl-4 space-y-1 border-l-2 border-sae-border ml-4">
                            {item.children.map((child) => (
                              <Link 
                                key={child.path}
                                to={child.path}
                                className="block px-4 py-2 text-sm text-sae-muted hover:text-sae-accent"
                              >
                                {child.label}
                              </Link>
                            ))}
                          </div>
                        </div>
                      </div>
                    ) : (
                      <Link 
                        to={item.path}
                        className="block px-4 py-3 font-medium text-sae-text hover:bg-sae-card rounded-lg transition-colors"
                      >
                        {item.label}
                      </Link>
                    )}
                  </div>
                ))}
              </nav>
            </div>

            <div className="p-6 border-t border-sae-border bg-sae-card/30">
              <Link to="/evolucao" className="flex items-center gap-3">
                <div className="w-10 h-10 bg-sae-card border border-sae-border rounded-full flex items-center justify-center text-sae-accent">
                  <User size={20} />
                </div>
                <div>
                  <div className="text-sm font-bold">Vendedor Exemplo</div>
                  <div className="text-xs text-sae-muted">Ver Perfil</div>
                </div>
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* --- MAIN CONTENT --- */}
      <main className="flex-grow">
        {children}
      </main>

      {/* --- FOOTER --- */}
      <footer className="bg-sae-darker border-t border-sae-border pt-16 pb-8">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
            <div>
              <div className="flex items-center gap-2 mb-6">
                <div className="w-8 h-8 bg-sae-accent rounded-md flex items-center justify-center text-sae-darker font-bold text-lg">S</div>
                <span className="font-bold text-xl text-white">SAE<span className="text-sae-accent">.</span></span>
              </div>
              <p className="text-sae-muted text-sm leading-relaxed mb-6">
                Sistema de Apoio Educacional. Transformando a gestão de cursos e o aprendizado corporativo com tecnologia e inovação.
              </p>
              <div className="flex gap-4">
                {[Facebook, Twitter, Instagram, Youtube].map((Icon, idx) => (
                  <a key={idx} href="#" className="w-8 h-8 rounded-full bg-sae-card border border-sae-border flex items-center justify-center text-sae-muted hover:bg-sae-accent hover:text-sae-darker transition-all">
                    <Icon size={16} />
                  </a>
                ))}
              </div>
            </div>

            <div>
              <h4 className="font-bold text-white mb-6">Links Rápidos</h4>
              <ul className="space-y-3 text-sm text-sae-muted">
                <li><Link to="/sobre" className="hover:text-sae-accent transition-colors">Sobre a Instituição</Link></li>
                <li><Link to="/equipe" className="hover:text-sae-accent transition-colors">Nossa Equipe</Link></li>
                <li><Link to="/videos" className="hover:text-sae-accent transition-colors">Tutoriais em Vídeo</Link></li>
                <li><Link to="/avisos" className="hover:text-sae-accent transition-colors">Mural de Avisos</Link></li>
                <li><Link to="/politica" className="hover:text-sae-accent transition-colors">Política de Privacidade</Link></li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold text-white mb-6">Cursos Populares</h4>
              <ul className="space-y-3 text-sm text-sae-muted">
                <li><Link to="/cursos/info" className="hover:text-sae-accent transition-colors">Gestão de Vendas</Link></li>
                <li><Link to="/cursos/info" className="hover:text-sae-accent transition-colors">Liderança Moderna</Link></li>
                <li><Link to="/cursos/info" className="hover:text-sae-accent transition-colors">Marketing Digital</Link></li>
                <li><Link to="/cursos/info" className="hover:text-sae-accent transition-colors">Finanças Corporativas</Link></li>
                <li><Link to="/cursos/combos" className="hover:text-sae-accent transition-colors text-sae-accentAlt">Ver Combos & Ofertas</Link></li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold text-white mb-6">Contatos</h4>
              <ul className="space-y-4 text-sm text-sae-muted">
                <li className="flex items-start gap-3">
                  <MapPin size={18} className="text-sae-accent shrink-0 mt-0.5" />
                  <span>Av. Paulista, 1000, Bela Vista<br/>São Paulo - SP</span>
                </li>
                <li className="flex items-center gap-3">
                  <Phone size={18} className="text-sae-accent shrink-0" />
                  <span>(11) 3000-0000</span>
                </li>
                <li className="flex items-center gap-3">
                  <Mail size={18} className="text-sae-accent shrink-0" />
                  <span>contato@sae-educacional.com</span>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="pt-8 border-t border-sae-border flex flex-col md:flex-row items-center justify-between text-xs text-sae-muted">
            <p>&copy; 2024 Sistema de Apoio Educacional. Todos os direitos reservados.</p>
            <div className="flex gap-6 mt-4 md:mt-0">
              <a href="#" className="hover:text-white">Termos de Uso</a>
              <a href="#" className="hover:text-white">Suporte</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};